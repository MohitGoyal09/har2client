#!/usr/bin/env python3
"""Run the case 3 v3 evaluation suite over several days inside the daily output allowance (PREREG.md, H16-H21), then case 1 Tier B at medium and xhigh.

Usage (from a frozen checkout; runs for days, resumes where it stopped):
  nohup caffeinate -i uv run python scripts/v3_eval_driver.py > runs/v3eval.log 2>&1 &

Steps, in this order (PREREG.md H22-H23 and H10, dated 2026-10-26): (1) the core steps: for each effort (low, high, medium), the
base arm and then the hint arm, one `run_batch.py` call each, into `runs/batch/v3eval_<arm>_<effort>`, then the 50 Tier B tasks at
medium into `runs/batch/tierb50_medium`; (2) the rest of base at xhigh; (3) the controls: the placebo and notice arms at low, base
and hint at low again (r2, to measure run-to-run variation), then the 25 hidden-header Tier B tasks with the hint and evidence
copies at high (H10, `runs/batch/tierb50_header_high`); (4) hint at xhigh; (5) Tier B at xhigh.
A step that exits 0 is done (`.done` marker). While a step runs, the driver reads the remaining daily
output tokens every POLL_S seconds and stops the step (SIGINT: run_batch finishes the cells in flight, writes
results.csv, and keeps the rest for the next call) when the allowance falls below RESERVE plus the cells in flight. It then
sleeps to the next 00:00 UTC reset and resumes. RESERVE is a small safety margin (the teammate uses a separate key).
"""

from __future__ import annotations

import csv
import datetime as dt
import json
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESERVE = 20_000  # output tokens per day kept as a safety margin (the teammate has a separate key)
CONCURRENCY = 8
POLL_S = 120
RESET_PAD_S = 300  # wait this long after 00:00 UTC
STOP_WAIT_S = 1800  # time for the cells in flight to finish after SIGINT
API_ERROR_RETRIES = 3  # a finished step with api_error cells runs again this often (run_batch retries them)
FALLBACK_OUT = {  # output tokens per solve before a step has measured its own (v3 pilot, Tier B run 1; medium, xhigh guessed)
    "v3eval": {"low": 1700, "medium": 4000, "high": 7500, "xhigh": 18000},
    "tierb50": {"medium": 2800, "high": 4900, "xhigh": 11000},
}
ARMS = (("base", "runs/heal_v3_eval"), ("hint", "runs/heal_v3_eval_hint"))
EFFORTS = ("low", "high", "medium", "xhigh")
# (group, tasks, effort, out), in the run order of PREREG.md H22-H23 and H10 (2026-10-26): the core steps (case 3 v3 at low, high,
# medium; then case 1 Tier B medium; low and high are in results/tierb50_v1.csv); base xhigh; the controls (placebo, notice, base r2,
# hint r2, H10 header copies at high); then hint xhigh and Tier B xhigh last, as optional extras (PREREG.md deviation 2026-10-24)
STEPS = (
    [("v3eval", tasks, effort, f"runs/batch/v3eval_{arm}_{effort}") for effort in ("low", "high", "medium") for arm, tasks in ARMS]
    + [("tierb50", "runs/tierb50", "medium", "runs/batch/tierb50_medium")]
    + [("v3eval", "runs/heal_v3_eval", "xhigh", "runs/batch/v3eval_base_xhigh")]
    + [
        ("v3eval", "runs/heal_v3_eval_placebo", "low", "runs/batch/v3eval_placebo_low"),
        ("v3eval", "runs/heal_v3_eval_notice", "low", "runs/batch/v3eval_notice_low"),
        ("v3eval", "runs/heal_v3_eval", "low", "runs/batch/v3eval_base_low_r2"),
        ("v3eval", "runs/heal_v3_eval_hint", "low", "runs/batch/v3eval_hint_low_r2"),
        ("tierb50", "runs/tierb50_header", "high", "runs/batch/tierb50_header_high"),
    ]
    + [("v3eval", "runs/heal_v3_eval_hint", "xhigh", "runs/batch/v3eval_hint_xhigh")]
    + [("tierb50", "runs/tierb50", "xhigh", "runs/batch/tierb50_xhigh")]
)


def log(msg: str) -> None:
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {msg}", flush=True)


def remaining_output() -> int:
    """Remaining daily output tokens, from the headers of a 1-token call."""
    key = next(l.split("=", 1)[1].strip() for l in (ROOT / ".env").read_text().splitlines() if l.startswith("REFLECTION_API_KEY="))
    body = json.dumps({"model": "Beam-1.0-501B-A23B", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 1, "reasoning_effort": "low"}).encode()
    req = urllib.request.Request("https://api.reflection.ai/openai/v1/chat/completions", data=body,
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return int(resp.headers["x-ratelimit-remaining-output-tokens-day"])
    except urllib.error.HTTPError as exc:  # 429 when the day is spent
        if exc.code == 429:
            return 0
        raise


def mean_output(group: str, effort: str) -> float:
    """Measured mean output tokens per solve at `effort` over the steps of `group`, else the fallback."""
    vals = []
    for g, _, e, out in STEPS:
        p = ROOT / out / "results.csv"
        if g == group and e == effort and p.exists():
            vals += [int(r["completion_tokens"]) for r in csv.DictReader(p.open()) if r.get("completion_tokens") and r.get("status") != "api_error"]
    return sum(vals) / len(vals) if len(vals) >= 8 else FALLBACK_OUT[group][effort]


def sleep_to_reset() -> None:
    now = dt.datetime.now(dt.timezone.utc)
    reset = (now + dt.timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0) + dt.timedelta(seconds=RESET_PAD_S)
    log(f"SLEEP until {reset.isoformat()}")
    time.sleep(max(60.0, (reset - now).total_seconds()))


def api_errors(out: str) -> int:
    p = ROOT / out / "results.csv"
    return sum(r.get("status") == "api_error" for r in csv.DictReader(p.open())) if p.exists() else 0


def run_step(group: str, tasks: str, effort: str, out: str) -> bool:
    """One run_batch call, stopped when the allowance gets low. True when the step finished (exit 0)."""
    per_solve = mean_output(group, effort)
    floor = RESERVE + CONCURRENCY * per_solve * 1.5
    left = remaining_output()
    log(f"step {out} remaining={left} floor={floor:.0f}")
    if left < floor + CONCURRENCY * per_solve:
        return False
    cmd = ["uv", "run", "python", "scripts/run_batch.py", "--tasks", tasks, "--out", out, "--effort", effort,
           "--runs", "1", "--concurrency", str(CONCURRENCY)]
    log("RUN " + " ".join(cmd))
    proc = subprocess.Popen(cmd, cwd=ROOT)
    while proc.poll() is None:
        time.sleep(POLL_S)
        if proc.poll() is None and remaining_output() < floor:
            log(f"STOP {out}: allowance below {floor:.0f}")
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=STOP_WAIT_S)
            except subprocess.TimeoutExpired:
                proc.terminate()
                proc.wait()
    log(f"EXIT {out} rc={proc.returncode}")
    return proc.returncode == 0


def main() -> int:
    for group, tasks, effort, out in STEPS:
        marker, retries = ROOT / out / ".done", 0
        while not marker.exists():
            if run_step(group, tasks, effort, out):
                if api_errors(out) and retries < API_ERROR_RETRIES:
                    retries += 1
                    log(f"RETRY {out}: {api_errors(out)} api_error cells")
                    continue
                marker.write_text(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
                log(f"DONE {out} mean_output={mean_output(group, effort):.0f}")
            else:
                sleep_to_reset()
    log("ALL DONE")
    return 0


if __name__ == "__main__":
    sys.exit(main())
