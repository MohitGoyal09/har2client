# Nimium Invoices API

Write one Python file, `client.py`, that defines `class Client` for this API.
The file `session.har` is a browser recording of a user session. It holds real
requests and responses for this API, mixed with unrelated traffic.

## Constructor

`Client(base_url: str, username: str, password: str)`

- `base_url` is the API root and already includes any base path, with no trailing slash.
  In the recording it looks like `https://api.nimium.app/api`. Tests use another host and port.
- `username` and `password` are the account credentials. Some APIs use a single API key
  instead of a login; for those, `password` is the API key and `username` is not used.

## Methods

Tests call these methods in order, all on one `Client` instance, so anything the client
keeps (such as a login session) carries over from call to call. Each argument is a keyword
argument. A method that returns an invoice returns the invoice object itself, not a wrapper around it.

- `list_invoices(state: str | None = None) -> list[dict]`: Return every invoice, across all pages, in the order the server gives them. When `state` is given, return only the invoices whose `state` equals it.
- `get_invoice(id: str) -> dict`: Return the invoice with this id.
- `create_invoice(body: dict) -> dict`: Create an invoice from `body` (a JSON object with the invoice fields). Return the created invoice.
- `update_invoice(id: str, changes: dict) -> dict`: Change the given fields of an invoice. Return the updated invoice.
- `delete_invoice(id: str) -> None`: Delete the invoice. Return `None`.

## Rules

- Use only `httpx`, `requests` and the standard library.
- Do not hard-code the host or any credential. Use `base_url`, `username` and `password`.
- Add no methods for endpoints that are not listed.
- Tests run against a fresh server with new data and new credentials.
- `client.py` must import everything it uses (for example `from typing import Any` for the return annotations).
