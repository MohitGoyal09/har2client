# Mirra Samples API

Write one Python file, `client.py`, that defines `class Client` for this API.
The file `session.har` is a browser recording of a user session. It holds real
requests and responses for this API, mixed with unrelated traffic.

## Constructor

`Client(base_url: str, username: str, password: str)`

- `base_url` is the API root and already includes any base path, with no trailing slash.
  In the recording it looks like `https://api.mirra.app/v2`. Tests use another host and port.
- `username` and `password` are the account credentials. Some APIs use a single API key
  instead of a login; for those, `password` is the API key and `username` is not used.

## Methods

Tests call these methods in order, all on one `Client` instance, so anything the client
keeps (such as a login session) carries over from call to call. Each argument is a keyword
argument. A method that returns a sample returns the sample object itself, not a wrapper around it.

- `list_samples(lab: str | None = None) -> list[dict]`: Return every sample, across all pages, in the order the server gives them. When `lab` is given, return only the samples whose `lab` equals it.
- `get_sample(id: str) -> dict`: Return the sample with this id.
- `create_sample(body: dict) -> dict`: Create a sample from `body` (a JSON object with the sample fields). Return the created sample.
- `update_sample(id: str, changes: dict) -> dict`: Change the given fields of a sample. Return the updated sample.
- `delete_sample(id: str) -> None`: Delete the sample. Return `None`.

## Rules

- Use only `httpx`, `requests` and the standard library.
- Do not hard-code the host or any credential. Use `base_url`, `username` and `password`.
- Add no methods for endpoints that are not listed.
- Tests run against a fresh server with new data and new credentials.
- `client.py` must import everything it uses (for example `from typing import Any` for the return annotations).
