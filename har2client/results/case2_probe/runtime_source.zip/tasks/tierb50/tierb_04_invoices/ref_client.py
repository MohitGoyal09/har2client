"""Reference client generated from the Tier B spec. Uses only httpx and the standard library."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import httpx

_NEXT_LINK = re.compile(r'<([^>]+)>\s*;\s*rel="?next"?')


class Client:
    def __init__(self, base_url: str, username: str, password: str):
        self._base = base_url.rstrip("/")
        self._username = username
        self._password = password
        self._http = httpx.Client(timeout=30.0, trust_env=False)
        self._token: str | None = None
        self._csrf: str | None = None

    def close(self) -> None:
        self._http.close()

    def _headers(self, write: bool) -> dict:
        headers: dict = {}
        if write and self._csrf:
            headers['X-Csrf-Header'] = self._csrf
        return headers

    def _login(self) -> None:
        self._token = self._csrf = None
        payload = {'login': self._username, 'password': self._password}
        resp = self._http.post(self._base + '/auth/token', json=payload, headers=self._headers(False))
        resp.raise_for_status()
        body = self._data(resp)
        self._csrf = resp.headers['X-Csrf-Header']

    def _send(self, method: str, url: str, *, params: Any = None, body: Any = None, headers: dict | None = None) -> httpx.Response:
        write = method != "GET"
        if self._csrf is None:
            self._login()
        for attempt in (0, 1):
            resp = self._http.request(
                method, url if url.startswith("http") else self._base + url,
                params=params or None, json=body, headers={**self._headers(write), **(headers or {})},
            )
            if resp.status_code == 401 and attempt == 0:
                self._login()
                continue
            break
        resp.raise_for_status()
        return resp

    def _data(self, resp: httpx.Response) -> Any:
        body = resp.json()
        return body

    def _item_path(self, item_id: str) -> str:
        return '/items' + "/" + quote(item_id, safe="")

    def list_invoices(self, state: str | None = None) -> list[dict]:
        items: list = []
        params: dict = {'state': state} if state is not None else {}
        position: Any = None
        while True:
            query = dict(params)
            if position:
                query['after'] = position
            body = self._send('GET', '/items', params=query).json()
            page = body['records']
            items.extend(page)
            position = body['next_cursor']
            if not position:
                break
        return items

    def get_invoice(self, id: str) -> dict:
        resp = self._send('GET', self._item_path(id))
        return self._data(resp)

    def create_invoice(self, body: dict) -> dict:
        resp = self._send('POST', '/items', body=body)
        return self._data(resp)

    def update_invoice(self, id: str, changes: dict) -> dict:
        headers = None
        current = self._send('GET', self._item_path(id))
        headers = {"If-Match": current.headers["etag"]}
        resp = self._send('PATCH', self._item_path(id), body=changes, headers=headers)
        return self._data(resp)

    def delete_invoice(self, id: str) -> None:
        self._send('DELETE', self._item_path(id))
        return None
