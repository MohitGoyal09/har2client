"""Reference client generated from the Tier B spec. Uses only httpx and the standard library."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import httpx

_NEXT_LINK = re.compile(r'<([^>]+)>\s*;\s*rel="?next"?')


class Client:
    def __init__(self, base_url: str, username: str, password: str):
        self._base = base_url.rstrip("/")
        self._username = username
        self._password = password
        self._http = httpx.Client(timeout=30.0, trust_env=False)
        self._token: str | None = None
        self._csrf: str | None = None

    def close(self) -> None:
        self._http.close()

    def _headers(self, write: bool) -> dict:
        headers: dict = {}
        headers['X-App-Build'] = '5456'
        headers['X-Api-Token'] = self._password
        return headers

    def _send(self, method: str, url: str, *, params: Any = None, body: Any = None, headers: dict | None = None) -> httpx.Response:
        write = method != "GET"
        resp = self._http.request(
            method, url if url.startswith("http") else self._base + url,
            params=params or None, json=body, headers={**self._headers(write), **(headers or {})},
        )
        resp.raise_for_status()
        return resp

    def _data(self, resp: httpx.Response) -> Any:
        body = resp.json()
        return body["data"]

    def _item_path(self, item_id: str) -> str:
        return '/records' + "/" + quote(item_id, safe="")

    def list_samples(self, lab: str | None = None) -> list[dict]:
        items: list = []
        params: dict = {'lab': lab} if lab is not None else {}
        url: str | None = '/records'
        while url:
            resp = self._send('GET', url, params=params)
            items.extend(self._data(resp))
            params = None
            match = _NEXT_LINK.search(resp.headers.get("link", ""))
            url = match.group(1) if match else None
        return items

    def get_sample(self, id: str) -> dict:
        resp = self._send('GET', self._item_path(id))
        return self._data(resp)

    def create_sample(self, body: dict) -> dict:
        resp = self._send('POST', '/records', body=body)
        return self._data(resp)

    def update_sample(self, id: str, changes: dict) -> dict:
        headers = None
        current = self._send('GET', self._item_path(id))
        headers = {"If-Match": current.headers["etag"]}
        resp = self._send('PATCH', self._item_path(id), body=changes, headers=headers)
        return self._data(resp)

    def delete_sample(self, id: str) -> None:
        self._send('DELETE', self._item_path(id))
        return None
