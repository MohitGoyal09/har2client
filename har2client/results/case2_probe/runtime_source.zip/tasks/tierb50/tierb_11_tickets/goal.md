# Brovo Tickets API

Write one Python file, `client.py`, that defines `class Client` for this API.
The file `session.har` is a browser recording of a user session. It holds real
requests and responses for this API, mixed with unrelated traffic.

## Constructor

`Client(base_url: str, username: str, password: str)`

- `base_url` is the API root and already includes any base path, with no trailing slash.
  In the recording it looks like `https://api.brovo.dev/api`. Tests use another host and port.
- `username` and `password` are the account credentials. Some APIs use a single API key
  instead of a login; for those, `password` is the API key and `username` is not used.

## Methods

Tests call these methods in order, all on one `Client` instance, so anything the client
keeps (such as a login session) carries over from call to call. Each argument is a keyword
argument. A method that returns a ticket returns the ticket object itself, not a wrapper around it.

- `list_tickets(priority: str | None = None) -> list[dict]`: Return every ticket, across all pages, in the order the server gives them. When `priority` is given, return only the tickets whose `priority` equals it.
- `get_ticket(id: str) -> dict`: Return the ticket with this id.
- `create_ticket(body: dict) -> dict`: Create a ticket from `body` (a JSON object with the ticket fields). Return the created ticket.
- `update_ticket(id: str, changes: dict) -> dict`: Change the given fields of a ticket. Return the updated ticket.
- `delete_ticket(id: str) -> None`: Delete the ticket. Return `None`.

## Rules

- Use only `httpx`, `requests` and the standard library.
- Do not hard-code the host or any credential. Use `base_url`, `username` and `password`.
- Add no methods for endpoints that are not listed.
- Tests run against a fresh server with new data and new credentials.
- `client.py` must import everything it uses (for example `from typing import Any` for the return annotations).
