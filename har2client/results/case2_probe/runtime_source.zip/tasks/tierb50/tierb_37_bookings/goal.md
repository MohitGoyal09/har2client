# Zanora Bookings API

Write one Python file, `client.py`, that defines `class Client` for this API.
The file `session.har` is a browser recording of a user session. It holds real
requests and responses for this API, mixed with unrelated traffic.

## Constructor

`Client(base_url: str, username: str, password: str)`

- `base_url` is the API root and already includes any base path, with no trailing slash.
  In the recording it looks like `https://api.zanora.dev/v2`. Tests use another host and port.
- `username` and `password` are the account credentials. Some APIs use a single API key
  instead of a login; for those, `password` is the API key and `username` is not used.

## Methods

Tests call these methods in order, all on one `Client` instance, so anything the client
keeps (such as a login session) carries over from call to call. Each argument is a keyword
argument. A method that returns a booking returns the booking object itself, not a wrapper around it.

- `list_bookings(room: str | None = None) -> list[dict]`: Return every booking, across all pages, in the order the server gives them. When `room` is given, return only the bookings whose `room` equals it.
- `get_booking(id: str) -> dict`: Return the booking with this id.
- `create_booking(body: dict) -> dict`: Create a booking from `body` (a JSON object with the booking fields). Return the created booking.
- `update_booking(id: str, changes: dict) -> dict`: Change the given fields of a booking. Return the updated booking.
- `delete_booking(id: str) -> None`: Delete the booking. Return `None`.

## Rules

- Use only `httpx`, `requests` and the standard library.
- Do not hard-code the host or any credential. Use `base_url`, `username` and `password`.
- Add no methods for endpoints that are not listed.
- Tests run against a fresh server with new data and new credentials.
- `client.py` must import everything it uses (for example `from typing import Any` for the return annotations).
